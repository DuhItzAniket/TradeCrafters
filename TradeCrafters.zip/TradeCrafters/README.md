# TradeCrafters - Stock Market Simulation Application

A full-stack application that simulates stock market trading with real-time data and user portfolio management.

## 🚀 Features

- Real-time stock market simulation
- User portfolio management
- Buy/Sell stock functionality
- Historical data tracking
- User authentication and authorization
- Responsive web interface

## 🛠️ Tech Stack

- **Frontend**: React.js
- **Backend**: Node.js, Express.js
- **Database**: SQL
- **Authentication**: JWT
- **Styling**: CSS/SCSS

## 📋 Prerequisites

- Node.js (v14 or higher)
- npm (v6 or higher)
- SQL Database

## 🚀 Installation

1. Clone the repository:
```bash
git clone https://github.com/DuhItzAniket/TradeCrafters.git
cd StockSim
```

2. Install dependencies:
```bash
npm run install-all
```

3. Set up environment variables:
- Copy `.env.example` to `.env`
- Fill in the required environment variables

4. Start the application:
```bash
# Start backend server
npm run

# Start frontend development server (in a new terminal)
npm start
```

## 📁 Project Structure

```
StockSim/
├── client/           # React frontend
├── server/           # Node.js backend
│   ├── config/      # Configuration files
│   ├── controllers/ # Request handlers
│   ├── models/      # Database models
│   ├── routes/      # API routes
│   └── database/    # Database setup
└── sql/             # SQL scripts
```

## 🔧 Configuration

Create a `.env` file in the root directory with the following variables:
```
PORT=3000
DB_HOST=localhost
DB_USER=
DB_PASSWORD=
DB_NAME=
JWT_SECRET=
```

Project Link: https://github.com/DuhItzAniket/TradeCrafters.git